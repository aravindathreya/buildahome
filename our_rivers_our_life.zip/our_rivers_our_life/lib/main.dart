import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      home: MyHomePage(),
    );
  }
}

class MyCheckBox extends StatefulWidget {
  var value = false;
  var title = "";
  MyCheckBox(this.value, this.title);
  @override
  MyCheckBoxState createState() {
    return MyCheckBoxState(this.value, this.title);
  }
}

class MyCheckBoxState extends State<MyCheckBox>{
  var value = false;
  var title = "";
  MyCheckBoxState(this.value, this.title);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Checkbox(
          materialTapTargetSize: MaterialTapTargetSize.padded,
          activeColor: Colors.black,
          value: this.value,
          onChanged: (bool value) {
            setState(() {
              this.value = value;
            });
          },
        ),
        Container(
          padding: EdgeInsets.only(left:0),
          child: Text(this.title)
        )
      ],
    );
  }

  }

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  GoogleMapController mapController;

  void _getPosition () async{
    Position position = await Geolocator().getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    print(Position);
  }
  final LatLng _center = const LatLng(22.9716, 77.5946);
  var vis = false;
  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
    _getPosition();
    setState(() {
      final LatLng _center = const LatLng(12.9716, 77.5946);
      mapController.animateCamera(CameraUpdate.newLatLng(_center));

    });
  }
  final _controller = PageController();


  var  surroundings = ['Clothes washing',
    'Cattle grazing',
    'Vechicles',
    'Agricultural land',
    'Plantation',
    'Bridge',
    'Industry',
    'Temple',
    'Village',
    'Town',
    'Effluent discharge',
    'Sewage discharge',
    'Irrigation pump'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Container(
        padding: EdgeInsets.only(top: 30, left: 0),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: PageView(
//          physics: NeverScrollableScrollPhysics(),
          controller: _controller,
          children: <Widget>[

            ListView(
              children: <Widget>[
                LinearPercentIndicator(
                  padding: EdgeInsets.all(0),
                  lineHeight: 16.0,
                  width: MediaQuery.of(context).size.width,
                  percent: 0.166,
                  backgroundColor: Colors.lightBlue[200],
                  progressColor: Colors.blue[700],
                  linearStrokeCap: LinearStrokeCap.roundAll,
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 25),
                  child: Text("Step 1 of 6", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    padding: EdgeInsets.only(left: 25),
                    child: Text("General Information ", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(width: 0.8, color: Colors.black),
                          )),
                      margin: EdgeInsets.only(left: 25, top: 20),
                      padding: EdgeInsets.all(3),
                      child: Text("Activity Date",
                          style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey)),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(width: 0.8, color: Colors.black),
                          )),
                      margin: EdgeInsets.only(right: 25, top: 20),
                      padding: EdgeInsets.all(3),
                      child: Text("Activity time",
                          style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey)),
                    ),
                  ],
                ),
                Container(
                  decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(width: 0.8, color: Colors.grey),
                      )),
                  margin: EdgeInsets.only(left: 25, right: 25, top: 15
                  ),
                  child: TextFormField(
                    autocorrect: true,
                    keyboardType: TextInputType.text,
                    style: TextStyle(fontSize: 24),
                    decoration: InputDecoration(

                        focusColor: Colors.black,
                        hasFloatingPlaceholder: true,
                        alignLabelWithHint: true,
                        labelText: "School name",
                        contentPadding: EdgeInsets.all(3),
                        labelStyle: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                        ),
                        fillColor: Colors.white
                    ),
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'This field cannot be empty';
                      }
                      return null;
                    },
                  )
                ),
                Container(
                  decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(width: 0.8, color: Colors.black),
                      )),
                  margin: EdgeInsets.only(left: 25, right: 25, top: 35),
                  padding: EdgeInsets.all(3),
                  child: Row(

                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        child: Text("Location",
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.grey)),
                      ),
                      Container(
                        child: Icon(Icons.my_location, color: Colors.grey,),
                      ),

                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width*0.35,
                      decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(width: 0.8, color: Colors.black),
                          )),
                      margin: EdgeInsets.only(left: 25, top: 30),
                      padding: EdgeInsets.all(3),
                      child: Text("Latitude",
                          style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey)),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width*0.45,
                      decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(width: 0.8, color: Colors.black),
                          )),
                      margin: EdgeInsets.only(right: 25, top: 30),
                      padding: EdgeInsets.all(3),
                      child: Text("Longitude",
                          style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey)),
                    ),
                  ],
                ),

                Container(
                  padding: EdgeInsets.all(25),
                  height: MediaQuery.of(context).size.height* .4,
                  width: MediaQuery.of(context).size.width,
                  child: GoogleMap(

                    onMapCreated: _onMapCreated,
                    initialCameraPosition: CameraPosition(
                      target: _center,
                      zoom: 11.0,
                    ),)
                ),

                Container(
                    decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(width: 0.8, color: Colors.grey),
                        )),
                    margin: EdgeInsets.only(left: 25, right: 25, top: 15, bottom: 30),
                    child: TextFormField(
                      autocorrect: true,
                      keyboardType: TextInputType.text,
                      style: TextStyle(fontSize: 24),
                      decoration: InputDecoration(

                          focusColor: Colors.black,
                          hasFloatingPlaceholder: true,
                          alignLabelWithHint: true,
                          labelText: "Name of the project",
                          contentPadding: EdgeInsets.all(3),
                          labelStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                          ),
                          fillColor: Colors.white
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'This field cannot be empty';
                        }
                        return null;
                      },
                    )
                ),
                Container(
                  margin: EdgeInsets.all(25),
                  padding: EdgeInsets.only(top: 5, bottom: 5, left: 15),
                  alignment: Alignment.centerRight,
                  width: MediaQuery.of(context).size.width*0.8,
                  child:
                  InkWell(
                      onTap: (){
                        _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                      },
                      child: Container(
                      padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          color: Colors.blueGrey[900]
                      ),
                      child: Text("Next", style: TextStyle(color: Colors.white, fontSize: 16),),)
                  ),
                ),
              ],

            ),
            ListView(
              children: <Widget>[
                LinearPercentIndicator(
                  padding: EdgeInsets.all(0),
                  lineHeight: 16.0,
                  width: MediaQuery.of(context).size.width,
                  percent: 0.3222,
                  backgroundColor: Colors.lightBlue[200],
                  progressColor: Colors.blue[700],
                  linearStrokeCap: LinearStrokeCap.roundAll,
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Step 2 of 6", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    padding: EdgeInsets.only(left: 25),
                    child: Text("Water Level and Weather", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),

                Container(
                    padding: EdgeInsets.only(top: 20, left: 25, bottom: 5),
                    child: Text("Measure the air temperature", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                        padding: EdgeInsets.only(left: 25),
                        width: 100,
                        child: TextFormField(
                          autocorrect: true,
                          keyboardType: TextInputType.number,
                          style: TextStyle(fontSize: 24),
                          decoration: InputDecoration(

                              focusColor: Colors.black,

                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide: BorderSide(
                                    color: Colors.red,
                                    width: 5.0),
                              ),

                              hasFloatingPlaceholder: false,
                              alignLabelWithHint: true,
                              contentPadding: EdgeInsets.only(left: 20, right: 20, top: 3, bottom: 3),
                              labelStyle: TextStyle(
                                color: Colors.grey,
                                fontSize: 16,
                              ),
                              fillColor: Colors.white
                          ),
                          validator: (value) {
                            if (value.isEmpty) {
                              return 'This field cannot be empty';
                            }
                            return null;
                          },
                        )
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 10),
                      child: Text("°C", style: TextStyle(color: Colors.grey),)
                    )
                  ],
                ),

                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Determine the depth of water ", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                  margin: EdgeInsets.only(left: 25, right: 25, top: 10),
                  child:
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),


                    ],
                  ),
                ),

                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("What's the weather like?", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                  margin: EdgeInsets.only(left: 25, right: 25, top: 10),
                  child:
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black)
                        ),
                      ),


                    ],
                  ),
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Notes (Optional)", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    margin: EdgeInsets.all(25),
                    alignment: Alignment.topLeft,

                    child: TextFormField(
                      autocorrect: true,
                      keyboardType: TextInputType.multiline,
                      maxLines: 8,
                      style: TextStyle(fontSize: 18),

                      decoration: InputDecoration(
                          focusColor: Colors.black,

                          hasFloatingPlaceholder: false,
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.indigo[900], width: 1.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.indigo[900], width: 1.0),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black, width: 1.0),
                          ),
                          filled: true,
                          alignLabelWithHint: true,
                          labelText: "Notes",
                          labelStyle: TextStyle(
                            fontSize: 18,
                          ),
                          fillColor: Colors.white
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'This field cannot be empty';
                        }
                        return null;
                      },
                    )),
                Container(
                  margin: EdgeInsets.all(25),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[

                      InkWell(
                          onTap: (){
                            _controller.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white12
                            ),
                            child: Text("< Back", style: TextStyle(color: Colors.blueGrey[800], fontSize: 16),),)
                      ),
                      InkWell(
                          onTap: (){
                            _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.blueGrey[900]
                            ),
                            child: Text("Next", style: TextStyle(color: Colors.white, fontSize: 16),),)
                      ),
                    ],
                  ),

                ),
              ],

            ),
            ListView(
              children: <Widget>[
                LinearPercentIndicator(
                  padding: EdgeInsets.all(0),
                  lineHeight: 16.0,
                  width: MediaQuery.of(context).size.width,
                  percent: 0.488,
                  backgroundColor: Colors.lightBlue[200],
                  progressColor: Colors.blue[700],
                  linearStrokeCap: LinearStrokeCap.roundAll,
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Step 3 of 6", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    padding: EdgeInsets.only(left: 25, bottom: 15),
                    child: Text("Observe the Surroundings", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(left: 25, right: 25),
                      width: MediaQuery.of(context).size.width ,
                      child: RawKeyboardListener(
                        onKey: (RawKeyEvent event) {
                          print("HIiiiiiiii"+event.data.logicalKey.keyId.toString());
                        },
                        focusNode: FocusNode(),
                        child: TextFormField(

                          textCapitalization: TextCapitalization.sentences,
                          decoration:InputDecoration(
                            suffixIcon: Container(
                                child: InkWell(
                                  child: Icon(
                                    Icons.search,
                                    color: Colors.grey,
                                  ),
                                )),

                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30),
                              borderSide: BorderSide(color: Colors.black, width: 10.0),
                            ),
                            contentPadding: EdgeInsets.only(left: 10, right: 10, top: 0),
                            labelStyle: TextStyle(
                              fontSize: 18,

                            ),
                          ),
                          style: TextStyle(fontSize: 16),


                        ),
                      ),

                    ),

                  ],
                ),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: new BouncingScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    itemCount: surroundings.length,
                    itemBuilder: (BuildContext ctxt, int Index) {
                        return Container(
                          padding: EdgeInsets.only(left: 25),
                          child: MyCheckBox(false, surroundings[Index])
                        );
                    }
                  ),
                InkWell(
                  onTap: () {
                    setState(() {
                      vis = vis == false? true : false;
                    });
                  },
                  child: Container(
                      padding: EdgeInsets.only(top: 20, left: 25),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Icon(Icons.add_circle, color: Colors.indigoAccent, size: 30),
                          Container(
                              padding: EdgeInsets.only(left: 10),
                              child: Text("Others", style: TextStyle(fontSize: 16, color: Colors.indigoAccent),)
                          ),

                        ],
                      )
                  ),
                ),

                Visibility(
                  visible: vis,
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 25, vertical: 5),
                    child: TextFormField(

                      textCapitalization: TextCapitalization.sentences,
                      decoration:InputDecoration(


                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide(color: Colors.black, width: 10.0),
                        ),
                        contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                        labelStyle: TextStyle(
                          fontSize: 18,

                        ),
                      ),
                      style: TextStyle(fontSize: 16),


                    ),
                  ),
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Would you like to elaborate (Optional)", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    margin: EdgeInsets.only(left: 25, right: 25, bottom: 25, top: 10),
                    alignment: Alignment.topLeft,

                    child: TextFormField(
                      autocorrect: true,
                      keyboardType: TextInputType.multiline,
                      maxLines: 3,
                      style: TextStyle(fontSize: 18),

                      decoration: InputDecoration(
                          focusColor: Colors.black,

                          hasFloatingPlaceholder: false,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.indigo[900], width: 1.0),
                          ),
                          filled: true,
                          alignLabelWithHint: true,
                          labelText: "Notes",
                          labelStyle: TextStyle(
                            fontSize: 18,
                          ),
                          fillColor: Colors.white
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'This field cannot be empty';
                        }
                        return null;
                      },
                    )),


                Container(
                  margin: EdgeInsets.all(25),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[

                      InkWell(
                          onTap: (){
                            _controller.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white12
                            ),
                            child: Text("< Back", style: TextStyle(color: Colors.blueGrey[800], fontSize: 16),),)
                      ),
                      InkWell(
                          onTap: (){
                            _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.blueGrey[900]
                            ),
                            child: Text("Next", style: TextStyle(color: Colors.white, fontSize: 16),),)
                      ),
                    ],
                  ),

                ),

              ],
            ),
            ListView(
              children: <Widget>[
                LinearPercentIndicator(
                  padding: EdgeInsets.all(0),
                  lineHeight: 16.0,
                  width: MediaQuery.of(context).size.width ,
                  percent: 0.644,
                  backgroundColor: Colors.lightBlue[200],
                  progressColor: Colors.blue[700],
                  linearStrokeCap: LinearStrokeCap.roundAll,
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Step 4 of 6", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    padding: EdgeInsets.only(left: 25, bottom: 15),
                    child: Text("Water Testing", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),
                Container(
                  margin: EdgeInsets.only(top: 25, left: 25, right:25, bottom: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        width: (MediaQuery.of(context).size.width-60)/2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.only(bottom: 5, left: 10),
                              child: Text("Water temperature", style: TextStyle(fontSize: 16),),
                            ),
                            IntrinsicHeight(
                              child: TextFormField(

                                textCapitalization: TextCapitalization.sentences,
                                decoration:InputDecoration(

                                  suffixIcon:
                                  Container(
                                      padding: EdgeInsets.only(top: 5, ),
                                      child:Text("°C", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30),
                                    borderSide: BorderSide(color: Colors.black, width: 10.0),
                                  ),
                                  contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                  labelStyle: TextStyle(
                                    fontSize: 18,

                                  ),
                                ),
                                style: TextStyle(fontSize: 16),


                              ),
                            ),

                          ],
                        )
                      ),
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("pH", style: TextStyle(fontSize: 16),),
                              ),

                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("Units", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),
                            ],
                          )
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Dissolved Oxygen", style: TextStyle(fontSize: 16),),
                              ),
                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("mg/L", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),

                            ],
                          )
                      ),
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Hardness", style: TextStyle(fontSize: 16),),
                              ),

                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("mg/L", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),
                            ],
                          )
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Nitrate", style: TextStyle(fontSize: 16),),
                              ),
                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("mg/L", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),

                            ],
                          )
                      ),
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Nitrite", style: TextStyle(fontSize: 16),),
                              ),

                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("mg/L", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),
                            ],
                          )
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Chlorine", style: TextStyle(fontSize: 16),),
                              ),
                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("mg/L", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),

                            ],
                          )
                      ),
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Alkalinity", style: TextStyle(fontSize: 16),),
                              ),

                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("pH", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),
                            ],
                          )
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Iron", style: TextStyle(fontSize: 16),),
                              ),
                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(

                                    suffixIcon:
                                    Container(
                                        padding: EdgeInsets.only(top: 5, ),
                                        child:Text("mg/L", style: TextStyle(color: Colors.grey, fontSize: 16),)),

                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),

                            ],
                          )
                      ),
                      Container(
                          width: (MediaQuery.of(context).size.width-60)/2,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("E Coli/Coliform Bacteria", style: TextStyle(fontSize: 16),),
                              ),

                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(


                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),
                            ],
                          )
                      )

                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                          width: (MediaQuery.of(context).size.width-50),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding: EdgeInsets.only(bottom: 5, left: 10),
                                child: Text("Turbidity", style: TextStyle(fontSize: 16),),
                              ),
                              IntrinsicHeight(
                                child: TextFormField(

                                  textCapitalization: TextCapitalization.sentences,
                                  decoration:InputDecoration(


                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30),
                                      borderSide: BorderSide(color: Colors.black, width: 10.0),
                                    ),
                                    contentPadding: EdgeInsets.only(left: 10, right: 0, top: 5, bottom: 5),
                                    labelStyle: TextStyle(
                                      fontSize: 18,

                                    ),
                                  ),
                                  style: TextStyle(fontSize: 16),


                                ),
                              ),

                            ],
                          )
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(25),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[

                      InkWell(
                          onTap: (){
                            _controller.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white12
                            ),
                            child: Text("< Back", style: TextStyle(color: Colors.blueGrey[800], fontSize: 16),),)
                      ),
                      InkWell(
                          onTap: (){
                            _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.blueGrey[900]
                            ),
                            child: Text("Next", style: TextStyle(color: Colors.white, fontSize: 16),),)
                      ),
                    ],
                  ),

                ),
              ],
            ),
            ListView(
              children: <Widget>[
                LinearPercentIndicator(
                  padding: EdgeInsets.all(0),
                  lineHeight: 16.0,
                  width: MediaQuery.of(context).size.width ,
                  percent: 0.8,
                  backgroundColor: Colors.lightBlue[200],
                  progressColor: Colors.blue[700],
                  linearStrokeCap: LinearStrokeCap.roundAll,
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Step 5 of 6", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    padding: EdgeInsets.only(left: 25, bottom: 15),
                    child: Text("Flora", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),

                Container(
                    padding: EdgeInsets.symmetric(horizontal: 25),
                    child: Text("Record the vegetation you can see around you. This could include grasses, shrubs, plants and trees", style: TextStyle(fontSize: 15, color: Colors.black,),)
                ),
                Container(
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue[600],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text("Upload a Flora Image", style: TextStyle(fontSize: 18, color: Colors.white,),)
                ),

                Container(
                    padding: EdgeInsets.symmetric(horizontal: 30),
                    child: Text("We support image format (JPEG and PNG) and video format (MP4 and OGG). Please make sure that your files are not more than 2MB.", style: TextStyle(fontSize: 15, color: Colors.grey,),)
                ),

                Container(
                    padding: EdgeInsets.only(left: 25, bottom: 15, top: 30),
                    child: Text("Fauna", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),

                Container(
                    padding: EdgeInsets.symmetric(horizontal: 25),
                    child: Text("Record fish, amphibians, reptiles, birds, insects and mammals that you see around you.", style: TextStyle(fontSize: 15, color: Colors.black,),)
                ),
                Container(
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue[600],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text("Upload a Fauna Image", style: TextStyle(fontSize: 18, color: Colors.white,),)
                ),

                Container(
                    padding: EdgeInsets.symmetric(horizontal: 30),
                    child: Text("We support image format (JPEG and PNG) and video format (MP4 and OGG). Please make sure that your files are not more than 2MB.", style: TextStyle(fontSize: 15, color: Colors.grey,),)
                ),
                Container(
                  margin: EdgeInsets.all(25),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[

                      InkWell(
                          onTap: (){
                            _controller.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white12
                            ),
                            child: Text("< Back", style: TextStyle(color: Colors.blueGrey[800], fontSize: 16),),)
                      ),
                      InkWell(
                          onTap: (){
                            _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.linearToEaseOut);
                          },
                          child: Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10, left: 30, right: 30),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.blueGrey[900]
                            ),
                            child: Text("Next", style: TextStyle(color: Colors.white, fontSize: 16),),)
                      ),
                    ],
                  ),

                ),

              ],
            ),
            ListView(
              children: <Widget>[
                LinearPercentIndicator(
                  padding: EdgeInsets.all(0),
                  lineHeight: 16.0,
                  width: MediaQuery.of(context).size.width ,
                  percent: 1.0,
                  backgroundColor: Colors.lightBlue[200],
                  progressColor: Colors.blue[700],
                  linearStrokeCap: LinearStrokeCap.roundAll,
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 25),
                    child: Text("Step 6 of 6", style: TextStyle(fontSize: 16, color: Colors.grey),)
                ),
                Container(
                    padding: EdgeInsets.only(left: 25, bottom: 25),
                    child: Text("Pictures(optional)", style: TextStyle(fontSize: 26, color: Colors.black,),)
                ),

                Container(
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue[600],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text("Upload Group picture", style: TextStyle(fontSize: 18, color: Colors.white,),)
                ),
                Container(
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue[600],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text("Upload Activity picture", style: TextStyle(fontSize: 18, color: Colors.white,),)
                ),
                Container(
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue[600],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text("Upload Artworks", style: TextStyle(fontSize: 18, color: Colors.white,),)
                ),
              ],

            ),
          ],
        )
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
